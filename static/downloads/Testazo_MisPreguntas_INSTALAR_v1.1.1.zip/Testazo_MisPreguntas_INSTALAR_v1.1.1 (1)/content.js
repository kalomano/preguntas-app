(() => {
  "use strict";
  if (globalThis.__testazoBridgeInjected) return;
  globalThis.__testazoBridgeInjected = true;

  let busy = false;
  let pendingJobId = null;
  let pendingTimeout = null;
  const earlyResults = new Map();
  let toastTimer;
  const BTN_ID = "tp-save-question-btn";
  const TOAST_ID = "tp-toast";

  function finishSave(result) {
    if (pendingTimeout) clearTimeout(pendingTimeout);
    pendingTimeout = null;
    pendingJobId = null;
    busy = false;
    const btn = document.getElementById(BTN_ID);
    if (btn) {
      btn.disabled = false;
      btn.textContent = "↗ Guardar en Preguntas";
    }
    if (!result?.ok) {
      toast("✕ " + (result?.message || "No se pudo guardar."), "error", true);
    } else if (result.status === "duplicate") {
      toast("Esta pregunta ya estaba guardada" + (result.profile ? " en «" + result.profile + "»" : " en tu aplicación") + ".", "info");
    } else {
      toast("✓ ¡Pregunta guardada correctamente" + (result.profile ? " en «" + result.profile + "»" : " en Mis Preguntas") + "!", "success");
    }
  }

  chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    if (message?.type === "TRIGGER_SAVE_FROM_TOOLBAR") {
      void saveQuestion();
      sendResponse({ ok: true });
      return false;
    }
    if (message?.type !== "QUESTION_SAVE_RESULT") return;
    if (pendingJobId === message.jobId) finishSave(message.result);
    else if (busy && !pendingJobId && message.jobId) earlyResults.set(message.jobId, message.result);
  });

  function toast(message, type = "info", persistent = false) {
    let el = document.getElementById(TOAST_ID);
    if (!el) {
      el = document.createElement("div");
      el.id = TOAST_ID;
      el.setAttribute("role", "status");
      el.setAttribute("aria-live", "polite");
      document.documentElement.appendChild(el);
    }
    el.textContent = message;
    el.dataset.type = type;
    if (toastTimer) clearTimeout(toastTimer);
    if (!persistent) toastTimer = setTimeout(() => el.remove(), 7500);
  }

  async function saveQuestion() {
    if (busy) {
      toast("Ya estamos guardando una pregunta, espera el resultado.", "info");
      return;
    }
    busy = true;
    const el = document.getElementById(BTN_ID);
    if (el) {
      el.disabled = true;
      el.textContent = "Enviando…";
    }
    try {
      const question = globalThis.TestazoBridgeExtractor.extractQuestion();
      toast("Conectando con Mis Preguntas. Si Render está dormido puede tardar cerca de un minuto…", "info", true);
      const ack = await chrome.runtime.sendMessage({
        type: "SAVE_QUESTION_IN_RENDER", question
      });
      if (!ack?.ok || !ack.jobId) {
        throw new Error(ack?.message || "La extensión no pudo preparar el envío.");
      }
      pendingJobId = ack.jobId;
      if (earlyResults.has(ack.jobId)) {
        const result = earlyResults.get(ack.jobId);
        earlyResults.clear();
        finishSave(result);
        return;
      }
      earlyResults.clear();
      pendingTimeout = setTimeout(() => {
        if (pendingJobId) finishSave({
          ok: false,
          message: "La espera superó tres minutos. Comprueba Mis Preguntas antes de volver a enviarla."
        });
      }, 180000);
    } catch (err) {
      finishSave({ ok: false, message: err?.message || "Error desconocido" });
    }
  }

  function button() {
    const el = document.createElement("button");
    el.id = BTN_ID;
    el.type = "button";
    el.title = "Guarda la pregunta con las cuatro opciones y la respuesta correcta";
    el.textContent = "↗ Guardar en Preguntas";
    el.addEventListener("click", (event) => {
      event.preventDefault();
      event.stopPropagation();
      void saveQuestion();
    });
    return el;
  }

  function ensureButton() {
    if (document.getElementById(BTN_ID)) return;
    if (!document.querySelector(".question-header .question-text")) return;
    const header = document.querySelector(".header-container");
    const placement = header?.querySelector(".flex.flex-row") || header;
    if (!placement) return;
    placement.insertBefore(button(), placement.firstChild);
  }

  ensureButton();
  let scheduled = false;
  new MutationObserver(() => {
    if (scheduled || document.getElementById(BTN_ID)) return;
    scheduled = true;
    requestAnimationFrame(() => {
      scheduled = false;
      ensureButton();
    });
  }).observe(document.body || document.documentElement, { childList: true, subtree: true });
})();
