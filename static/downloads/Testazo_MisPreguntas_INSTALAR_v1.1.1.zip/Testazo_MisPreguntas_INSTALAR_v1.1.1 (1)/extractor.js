/* Extracción desde la página visible; nunca consulta respuestas ocultas ni APIs de Testazo. */
(() => {
  "use strict";

  const clean = (value) => String(value || "").replace(/\s+/g, " ").trim();

  function extractQuestion() {
    // En el modo habitual de Testazo se muestra una pregunta cada vez.
    const header = Array.from(document.querySelectorAll(".question-header"))
      .find((node) => node.querySelector(".question-text"));
    if (!header) {
      throw new Error("No encuentro la pregunta de Testazo en esta pantalla.");
    }

    const container = header.closest("form") || document;
    const questionNode = header.querySelector(".question-text");
    const optionsContainer = container.querySelector(".options-container");
    if (!optionsContainer) {
      throw new Error("No encuentro las opciones de esta pregunta.");
    }

    const question = clean(questionNode.innerText || questionNode.textContent)
      .replace(/^\d+[.)]\s+/, "");
    const labels = Array.from(optionsContainer.querySelectorAll("label.option-label"));
    if (!question || labels.length !== 4) {
      throw new Error("La pregunta debe tener enunciado y cuatro opciones visibles.");
    }

    // El modelo actual de la app solo admite texto. No perder imágenes en silencio.
    if (questionNode.querySelector("img, canvas, video, svg") ||
        labels.some((label) => label.querySelector("img, canvas, video, svg"))) {
      throw new Error("Esta pregunta contiene imágenes. Guárdala como captura en tu aplicación para no perder información.");
    }

    const options = labels.map((label, i) => {
      const row = label.querySelector(":scope > div");
      const optionTextNode = row?.children?.[1];
      if (!optionTextNode) {
        throw new Error(`No puedo leer la opción ${i + 1}.`);
      }
      return {
        letter: "abcd"[i],
        text: clean(optionTextNode.innerText || optionTextNode.textContent)
      };
    });
    if (options.some((o) => !o.text)) {
      throw new Error("Alguna opción aparece vacía. No la voy a guardar incompleta.");
    }

    // Solo considerar respuestas que Testazo ya ha marcado como correctas en pantalla.
    const markedCorrect = labels
      .map((label, i) => label.classList.contains("option-label-correct") ? i : -1)
      .filter((i) => i !== -1);
    if (markedCorrect.length !== 1) {
      throw new Error("Responde primero la pregunta en modo estudio para que Testazo muestre la correcta.");
    }

    const topic = clean(container.querySelector(".header-title")?.textContent);
    return {
      question,
      options,
      correct_index: markedCorrect[0],
      topic,
      source_url: location.href,
      source_question_id: header.getAttribute("wire:key")?.match(/(\d+)$/)?.[1] || null
    };
  }

  globalThis.TestazoBridgeExtractor = { extractQuestion };
})();
