"use strict";

const APP_ORIGIN = "https://preguntas-app.onrender.com";
const TESTAZO_ORIGIN = "https://app.testazo.com";
const JOB_PREFIX = "pending_testazo_job_";
const WARM_ALARM = "testazo-active-study-warmup";
const running = new Set();

// Un clic en el icono de Chrome hace lo mismo que el botón incrustado en Testazo.
chrome.action.onClicked.addListener(async (tab) => {
  if (!tab?.id) return;
  if (!tab.url?.startsWith(TESTAZO_ORIGIN + "/")) {
    await chrome.action.setBadgeBackgroundColor({ tabId: tab.id, color: "#b91c1c" });
    await chrome.action.setBadgeText({ tabId: tab.id, text: "WEB" });
    await chrome.action.setTitle({ tabId: tab.id, title: "Abre una pregunta de Testazo para guardarla" });
    return;
  }
  try {
    await chrome.tabs.sendMessage(tab.id, { type: "TRIGGER_SAVE_FROM_TOOLBAR" });
  } catch (_) {
    // Si la extensión se acaba de instalar en una pestaña ya abierta, inyectar
    // los scripts una única vez para que no sea obligatorio encontrar el botón.
    try {
      await chrome.scripting.insertCSS({ target: { tabId: tab.id }, files: ["style.css"] });
      await chrome.scripting.executeScript({ target: { tabId: tab.id }, files: ["extractor.js", "content.js"] });
      await chrome.tabs.sendMessage(tab.id, { type: "TRIGGER_SAVE_FROM_TOOLBAR" });
    } catch (err) {
      await showBadge(tab.id, "!", "#b91c1c", "No puedo leer Testazo: recarga la página y vuelve a probar.");
    }
  }
});

async function showBadge(tabId, text, color, title) {
  if (!Number.isInteger(tabId)) return;
  try {
    await chrome.action.setBadgeBackgroundColor({tabId, color});
    await chrome.action.setBadgeText({tabId, text});
    await chrome.action.setTitle({tabId, title});
  } catch (_) {}
}

chrome.runtime.onMessage.addListener((message, sender, reply) => {
  if (message?.type !== "SAVE_QUESTION_IN_RENDER") return false;
  const sourceTab = sender.tab?.id;
  enqueueImport(message.question, sourceTab)
    .then((jobId) => {
      void showBadge(sourceTab, "···", "#0d9488", "Guardando en Mis Preguntas...");
      reply({ ok: true, jobId });
    })
    .catch((err) => {
      void showBadge(sourceTab, "!", "#b91c1c", err?.message || "Error preparando el envío.");
      reply({ ok: false, message: err?.message || "Error preparando el envío." });
    });
  return true;
});

chrome.tabs.onUpdated.addListener((tabId, change, tab) => {
  if (change.status !== "complete") return;
  if (tab.url?.startsWith(APP_ORIGIN + "/")) void processPending(tabId);
  // Empieza a despertar Render al entrar en Testazo, no al guardar la pregunta.
  if (tab.url?.startsWith(TESTAZO_ORIGIN + "/app/make-tests")) void warmRenderIfStudying();
});

chrome.tabs.onRemoved.addListener((tabId) => {
  void cancelIfPending(tabId);
});

async function enqueueImport(question, sourceTab) {
  if (!Number.isInteger(sourceTab) || !question || !question.question ||
      question.options?.length !== 4 ||
      !Number.isInteger(question.correct_index) ||
      question.correct_index < 0 || question.correct_index > 3 ||
      question.options.some((o, i) => !o.text || o.letter !== "abcd"[i])) {
    throw new Error("Datos de la pregunta incompletos; no se envió nada.");
  }

  const tabs = await chrome.tabs.query({ url: APP_ORIGIN + "/*" });
  const found = tabs.find((t) => t.status === "complete" &&
    !t.url?.includes("/users")) || tabs.find((t) => t.status === "complete") || tabs[0];
  const created = !found;
  const tab = found || await chrome.tabs.create({ url: APP_ORIGIN + "/", active: false });
  const jobId = crypto.randomUUID();
  const key = JOB_PREFIX + tab.id;
  const existing = (await chrome.storage.session.get(key))[key];
  if (existing) throw new Error("Hay otra pregunta esperando a Render. Espera a que se guarde.");

  await chrome.storage.session.set({
    [key]: { jobId, sourceTab, question, created }
  });

  if (tab.status === "complete") void processPending(tab.id);
  else void chrome.tabs.get(tab.id).then((fresh) => {
    if (fresh.status === "complete") return processPending(tab.id);
  }).catch(() => cancelIfPending(tab.id));

  return jobId;
}

async function cancelIfPending(tabId) {
  const key = JOB_PREFIX + tabId;
  const job = (await chrome.storage.session.get(key))[key];
  if (!job) return;
  await chrome.storage.session.remove(key);
  await notifySource(job, { ok: false, message: "Se cerró la pestaña de Mis Preguntas durante el guardado." });
}

async function processPending(tabId) {
  if (running.has(tabId)) return;
  running.add(tabId);
  const key = JOB_PREFIX + tabId;
  try {
    const job = (await chrome.storage.session.get(key))[key];
    if (!job) return;
    let result;
    try {
      const execution = await chrome.scripting.executeScript({
        target: { tabId },
        func: submitFormInsideRender,
        args: [job.question]
      });
      result = execution?.[0]?.result || {
        ok: false,
        message: "Render no ha confirmado el guardado. Comprueba la aplicación."
      };
      if (result.status === "login") {
        await chrome.tabs.update(tabId, { active: true, url: APP_ORIGIN + "/users" });
        result = {
          ok: false,
          message: "Abre Mis Preguntas, selecciona o crea tu usuario, y vuelve a pulsar Guardar en Testazo."
        };
      }
    } catch (err) {
      result = { ok: false, message: "Error hablando con Render: " + err.message };
      if (job.created) {
        try { await chrome.tabs.update(tabId, { active: true }); } catch (_) {}
      }
    }
    await chrome.storage.session.remove(key);
    await notifySource(job, result);
  } finally {
    running.delete(tabId);
  }
}

async function notifySource(job, result) {
  await showBadge(job.sourceTab,
    result?.ok ? (result.status === "duplicate" ? "=" : "✓") : "!",
    result?.ok ? "#15803d" : "#b91c1c",
    result?.ok ? (result.status === "duplicate" ? "La pregunta ya estaba guardada" : "Pregunta guardada correctamente") :
      (result?.message || "Error de guardado"));
  try {
    await chrome.tabs.sendMessage(job.sourceTab, {
      type: "QUESTION_SAVE_RESULT", jobId: job.jobId, result
    });
  } catch (_) {
    // El usuario cerró o recargó Testazo: no repetir automáticamente.
  }
}

// Se ejecuta en el contexto de Render y emplea la sesión del usuario ya
// seleccionado. No se comparten cookies con Testazo ni se cambia de perfil.
async function submitFormInsideRender(payload) {
  if (location.origin !== "https://preguntas-app.onrender.com") {
    return { ok: false, message: "Dominio de destino inesperado." };
  }
  if (location.pathname === "/users") return { ok: false, status: "login" };
  const form = new FormData();
  form.set("question", payload.question);
  form.set("options_json", JSON.stringify(payload.options));
  form.set("correct_index", String(payload.correct_index));
  try {
    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), 85000);
    let res;
    try {
      res = await fetch("/confirm-save", {
        method: "POST", body: form, credentials: "same-origin",
        redirect: "follow", signal: controller.signal
      });
    } finally {
      clearTimeout(timeout);
    }
    if (!res.ok) return { ok: false, message: `Error del servidor (${res.status}).` };
    if (new URL(res.url).pathname === "/users") {
      return { ok: false, status: "login" };
    }
    const doc = new DOMParser().parseFromString(await res.text(), "text/html");
    const notices = Array.from(doc.querySelectorAll(".flash"));
    const profileLabel = doc.querySelector(".badge")?.textContent?.trim() || "";
    const profile = profileLabel.startsWith("Usuario:") ? profileLabel.slice(8).trim() : "";
    const saved = notices.some((el) => el.classList.contains("success") &&
      el.textContent.includes("Guardada correctamente"));
    if (saved) return { ok: true, status: "saved", profile };
    const duplicate = notices.some((el) => el.textContent.includes("ya estaba guardada"));
    if (duplicate) return { ok: true, status: "duplicate", profile };
    const error = notices.find((el) => el.classList.contains("error"));
    return {
      ok: false,
      message: error?.textContent?.trim() || "El servidor no confirmó el guardado. Revisa Mis Preguntas antes de repetir."
    };
  } catch (err) {
    return { ok: false, message: "Error de conexión: " + err.message };
  }
}

// Render Free duerme tras 15 minutos sin peticiones. Se usa una petición
// HEAD ligera cada 10 min SOLO si Chrome está enfocado y Testazo está en una
// pestaña activa. No es un monitor 24/7 ni una garantía de disponibilidad.
async function warmRenderIfStudying() {
  try {
    const windows = await chrome.windows.getAll({ populate: true });
    const studying = windows.some((win) => win.focused && win.tabs?.some((tab) =>
      tab.active && tab.url?.startsWith(TESTAZO_ORIGIN + "/app/make-tests")));
    if (!studying) return;
    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), 20000);
    try {
      await fetch(APP_ORIGIN + "/users", {
        method: "HEAD", cache: "no-store", signal: controller.signal
      });
    } finally {
      clearTimeout(timeout);
    }
  } catch (_) {
    // No interrumpir el test si falla la comprobación de actividad.
  }
}

async function setupWarmAlarm() {
  await chrome.alarms.create(WARM_ALARM, { periodInMinutes: 10 });
}
chrome.runtime.onInstalled.addListener(() => { void setupWarmAlarm(); });
chrome.runtime.onStartup.addListener(() => { void setupWarmAlarm(); });
chrome.alarms.onAlarm.addListener((alarm) => {
  if (alarm.name === WARM_ALARM) void warmRenderIfStudying();
});
